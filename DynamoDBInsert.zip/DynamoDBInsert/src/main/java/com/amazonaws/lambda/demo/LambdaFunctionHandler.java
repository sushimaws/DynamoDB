package com.amazonaws.lambda.demo;

import java.util.List;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;

public class LambdaFunctionHandler implements RequestHandler<SQSEvent, String> {

	AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.US_EAST_1.getName()).build();
	DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
	
    @Override
    public String handleRequest(SQSEvent input, Context context) {
        context.getLogger().log("Input: " + input);

        Table table = dynamoDB.getTable("FileStatus");
        List<SQSMessage> messages = input.getRecords();
        String[] splitMessage = messages.get(0).getBody().split(":");
        Item item = new Item().withString("filename", splitMessage[1]).withString("status", "received");
        table.putItem(item);
        // TODO: implement your handler
        return "Hello from Lambda!";
    }

}
